import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom";
import Board, { moveCard } from "@lourenci/react-kanban";
import "@lourenci/react-kanban/dist/styles.css";

const board = {
  columns: [
    {
      id: 1,
      title: "Urgent",
      backgroundColor: "#fff",
      cards: [
        {
          id: 1,
          title: "IP exp ",
          description: "Complete the exps"
        },
        {
          id: 2,
          title: " PCOM Assignment",
          description: "Case study of radio frequency"
        },
      ]
    },
    {
      id: 2,
      title: "High",
      cards: [
        {
          id: 9,
          title: "Summary ",
          description: "Sumary of ADSA in sem 5"
        }
      ]
    },
    {
      id: 3,
      title: "Medium",
      cards: [
        {
          id: 10,
          title: "Mini Project",
          description: "Prepare the ppt"
        },
        {
          id: 11,
          title: "Quiz",
          description: "Complete quiz in erp"
        }
      ]
    },
    {
      id: 4,
      title: "Low",
      cards: [
        {
          id: 12,
          title: "BI exps",
          description: "Complete exp 1,2,3"
        },
      ]
    },
    {
      id: 1,
      title: "No Priority",
      backgroundColor: "#fff",
      cards: [
        {
          id: 1,
          title: "Complete",
          description: "The notes"
        },
      ]
    },
  ]
};

const items = [];

function UncontrolledBoard() {
  return (
    <Board
      allowRemoveLane
      allowRenameColumn
      allowRemoveCard
      onLaneRemove={console.log}
      onCardRemove={console.log}
      onLaneRename={console.log}
      initialBoard={board}
      allowAddCard={{ on: "top" }}
      onNewCardConfirm={(draftCard) => ({
        id: new Date().getTime(),
        ...draftCard
      })}
      onCardNew={console.log}
    />
  );
}

function App() {
  return (
    <>
     {items.length && <div />}
      
      <h1>Kanban board</h1>
      
      <UncontrolledBoard />
    </>
  );
}
const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);